import React from "react"
import Catalog from "./Catalog"

 function App(){
    return(
        <div className="allbody">
             <Catalog />
        </div>
    )
}

export default App
