import React from "react"
const kidsProducts= [
    {
        id: 1,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3e094ba9-472f-4187-b4f8-4313d5063578/sportswear-big-kids-boys-printed-t-shirt-gzk9px.png" height="150px"></img>,
        name:"Colorfull T-shirt",
        price:"50.00",
        
        
    },
    {
        id: 2,
        image:<img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/b3dc07b9-032f-4da0-9a69-7206a5303b15/sportswear-big-kids-boys-printed-t-shirt-extended-size-SZVm8b.png" height="150px"></img>,
        name:"Black T-Shirt",
        price: "70.00",
        
    },
    {  id: 3,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/914a534f-b507-4af8-82e8-cd85e5c1d883/sportswear-big-kids-girls-french-terry-printed-tank-p7vzcS.png" height="150px"></img>,
        name:"Sportwear",
        price:"$80.00",
        },
        {  id: 4,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/c904bf66-b84c-4032-b5d3-9d9c7b645a59/sportswear-script-big-kids-boys-printed-t-shirt-MNf7Qx.png" height="150px"></img>,
        name:"Red T-shirt",
        price:"$80.00",
        },
        {id: 5,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/6222632d-2c8c-4078-8511-14f69dac19b5/sportswear-big-kids-boys-t-shirt-54TZQj.png" height="150px"></img>,
        name:"Lightblue T-shirt",
        price:"$90.00",
        },
        {id: 6,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/d4e54679-de65-4065-85cb-6db3d61b4085/air-big-kids-boys-t-shirt-extended-size-8Z0T8b.png"></img>,
        name:"Lightgreen T-shirt",
        price:"$80.00",
        },
        {id: 7,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/37273695-555b-4e56-a833-1a09a1516a9d/polo-big-kids-polo-GnJrnB.png"></img>,
        name:"Black T-shirt",
        price:"$70.00",
        },
        {id: 8,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/d0cfd3fb-0911-4511-beb7-1e8e233b7c7b/sportswear-big-kids-girls-boxy-t-shirt-njhJdD.png"></img>,
        name:"Lightpink T-shirt",
        price:"$100.00",
        },
        {id: 9,
        image: <img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/ec2b6350-6f80-4322-8b52-4b412f560103/dri-fit-trophy-big-kids-girls-training-tank-extended-size-g49tjs.png"></img>,
        name:"Grey Sweat-shirt",
        price:"$70.00",
        }
        ]
export default kidsProducts